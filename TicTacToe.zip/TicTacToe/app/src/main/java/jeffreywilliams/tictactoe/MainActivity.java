package jeffreywilliams.tictactoe;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private final static String TAG = MainActivity.class.getSimpleName();
    boolean PLAYER_X = true;

    int TURN_COUNT = 0;

    String but00, but01, but02;
    String but10, but11, but12;
    String but20, but21, but22;

    Button button00, button01, button02;
    Button button10, button11, button12;
    Button button20, button21, button22;
    Button newGameButton;

    TextView displayText;

    int[][] boardStatus = new int[3][3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        button00 = findViewById(R.id.button00);
        button01 = findViewById(R.id.button01);
        button02 = findViewById(R.id.button02);

        button10 = findViewById(R.id.button10);
        button11 = findViewById(R.id.button11);
        button12 = findViewById(R.id.button12);

        button20 = findViewById(R.id.button20);
        button21 = findViewById(R.id.button21);
        button22 = findViewById(R.id.button22);

        newGameButton = findViewById(R.id.newGameButton);
        displayText = findViewById(R.id.displayText);

        newGameButton.setOnClickListener(this);

        button00.setOnClickListener(this);
        button01.setOnClickListener(this);
        button02.setOnClickListener(this);

        button10.setOnClickListener(this);
        button11.setOnClickListener(this);
        button12.setOnClickListener(this);

        button20.setOnClickListener(this);
        button21.setOnClickListener(this);
        button22.setOnClickListener(this);

        initializeBoardStatus();

        if (savedInstanceState != null) {
            but00 = savedInstanceState.getString("but00");
            if(but00 == "X" || but00 == "O" || but00 == "") {
                button00.setText(savedInstanceState.getString("but00"));
                boardStatus[0][0] = savedInstanceState.getInt("num00");
                button00.setEnabled(false);
            }

            but01 = savedInstanceState.getString("but01");
            if(but01 == "X" || but01 == "O" || but01 == "") {
                button01.setText(savedInstanceState.getString("but01"));
                boardStatus[0][2] = savedInstanceState.getInt("num01");
                button01.setEnabled(false);
            }

            but02 = savedInstanceState.getString("but02");
            if(but02 == "X" || but02 == "O" || but02 == "") {
                button02.setText(savedInstanceState.getString("but02"));
                boardStatus[0][2] = savedInstanceState.getInt("num02");
                button02.setEnabled(false);
            }

            but10 = savedInstanceState.getString("but10");
            if(but10 == "X" || but10 == "O" || but10 == "") {
                button10.setText(savedInstanceState.getString("but10"));
                boardStatus[1][0] = savedInstanceState.getInt("num10");
                button10.setEnabled(false);
            }

            but11 = savedInstanceState.getString("but11");
            if(but11 == "X" || but11 == "O" || but11 == "") {
                button11.setText(savedInstanceState.getString("but11"));
                boardStatus[1][1] = savedInstanceState.getInt("num11");
                button11.setEnabled(false);
            }

            but12 = savedInstanceState.getString("but12");
            if(but12 == "X" || but12 == "O" || but12 == "") {
                button12.setText(savedInstanceState.getString("but12"));
                boardStatus[1][2] = savedInstanceState.getInt("num12");
                button12.setEnabled(false);
            }

            but20 = savedInstanceState.getString("but20");
            if(but20 == "X" || but20 == "O" || but20 == "") {
                button20.setText(savedInstanceState.getString("but20"));
                boardStatus[2][0] = savedInstanceState.getInt("num20");
                button20.setEnabled(false);
            }

            but21 = savedInstanceState.getString("but21");
            if(but21 == "X" || but21 == "O" || but21 == "") {
                button21.setText(savedInstanceState.getString("but21"));
                boardStatus[2][1] = savedInstanceState.getInt("num21");
                button21.setEnabled(false);
            }

            but22 = savedInstanceState.getString("but22");
            if(but22 == "X" || but22 =="O" || but22 == "") {
                button22.setText(savedInstanceState.getString("but22"));
                boardStatus[2][2] = savedInstanceState.getInt("num22");
                button22.setEnabled(false);
            }

            displayText.setText(savedInstanceState.getString("text"));
            TURN_COUNT = savedInstanceState.getInt("turn");
            if (TURN_COUNT % 2 != 0)
                PLAYER_X = !PLAYER_X;
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

        if (!button00.isEnabled()) {
            outState.putString("but00", button00.getText().toString());
            outState.putInt("num00", boardStatus[0][0]);
        }

        if (!button01.isEnabled()) {
            outState.putString("but01", button01.getText().toString());
            outState.putInt("num01", boardStatus[0][1]);
        }

        if (!button02.isEnabled()) {
            outState.putString("but02", button02.getText().toString());
            outState.putInt("num02", boardStatus[0][2]);
        }

        if (!button10.isEnabled()) {
            outState.putString("but10", button10.getText().toString());
            outState.putInt("num10", boardStatus[1][0]);
        }

        if (!button11.isEnabled()) {
            outState.putString("but11", button11.getText().toString());
            outState.putInt("num11", boardStatus[1][1]);
        }

        if (!button12.isEnabled()) {
            outState.putString("but12", button12.getText().toString());
            outState.putInt("num12", boardStatus[1][2]);
        }

        if (!button20.isEnabled()) {
            outState.putString("but20", button20.getText().toString());
            outState.putInt("num20", boardStatus[2][0]);
        }

        if (!button21.isEnabled()) {
            outState.putString("but21", button21.getText().toString());
            outState.putInt("num21", boardStatus[2][1]);
        }

        if (!button22.isEnabled()) {
            outState.putString("but22", button22.getText().toString());
            outState.putInt("num22", boardStatus[2][2]);
        }

        outState.putString("text", displayText.getText().toString());
        outState.putInt("turn", TURN_COUNT);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onClick(View view) {
        Log.d(TAG, "Inside onClick");

        boolean resetButtonPressed = false;

        switch (view.getId()){
            case R.id.button00:
                if(PLAYER_X){
                    button00.setText("X");
                    boardStatus[0][0] = 1;
                }
                else{
                    button00.setText("O");
                    boardStatus[0][0] = 0;
                }
                button00.setEnabled(false);
                break;

            case R.id.button01:
                if(PLAYER_X){
                    button01.setText("X");
                    boardStatus[0][1] = 1;
                }
                else{
                    button01.setText("O");
                    boardStatus[0][1] = 0;
                }
                button01.setEnabled(false);
                break;

            case R.id.button02:
                if(PLAYER_X){
                    button02.setText("X");
                    boardStatus[0][2] = 1;
                }
                else{
                    button02.setText("O");
                    boardStatus[0][2] = 0;
                }
                button02.setEnabled(false);
                break;

            case R.id.button10:
                if(PLAYER_X){
                    button10.setText("X");
                    boardStatus[1][0] = 1;
                }
                else{
                    button10.setText("O");
                    boardStatus[1][0] = 0;
                }
                button10.setEnabled(false);
                break;

            case R.id.button11:
                if(PLAYER_X){
                    button11.setText("X");
                    boardStatus[1][1] = 1;
                }
                else{
                    button11.setText("O");
                    boardStatus[1][1] = 0;
                }
                button11.setEnabled(false);
                break;

            case R.id.button12:
                if(PLAYER_X){
                    button12.setText("X");
                    boardStatus[1][2] = 1;
                }
                else{
                    button12.setText("O");
                    boardStatus[1][2] = 0;
                }
                button12.setEnabled(false);
                break;

            case R.id.button20:
                if(PLAYER_X){
                    button20.setText("X");
                    boardStatus[2][0] = 1;
                }
                else{
                    button20.setText("O");
                    boardStatus[2][0] = 0;
                }
                button20.setEnabled(false);
                break;

            case R.id.button21:
                if(PLAYER_X){
                    button21.setText("X");
                    boardStatus[2][1] = 1;
                }
                else{
                    button21.setText("O");
                    boardStatus[2][1] = 0;
                }
                button21.setEnabled(false);
                break;

            case R.id.button22:
                if(PLAYER_X){
                    button22.setText("X");
                    boardStatus[2][2] = 1;
                }
                else{
                    button22.setText("O");
                    boardStatus[2][2] = 0;
                }
                button22.setEnabled(false);
                break;

            case R.id.newGameButton:
                resetButtonPressed = true;
                break;

            default:
                break;

        }

        if(resetButtonPressed){
            resetBoard();
        }
        else{
            TURN_COUNT ++;
                PLAYER_X = !PLAYER_X;

            if(PLAYER_X){
                setInfo("Player X's turn");
            }
            else {
                setInfo("Player O's turn");
            }

            if(TURN_COUNT==9){
                result("Tie Game");
            }

            checkWinner();
        }
    }

    private void checkWinner(){

        Log.d(TAG, "Inside checkWinner");

        for(int i=0; i<3; i++){
            if(boardStatus[i][0] == boardStatus[i][1] && boardStatus[i][0] == boardStatus[i][2]){
                if (boardStatus[i][0]==1){
                    result("X wins!");
                    break;
                }
                else if (boardStatus[i][0]==0) {
                    result("O wins!");
                    break;
                }
            }
        }

        for(int i=0; i<3; i++){
            if(boardStatus[0][i] == boardStatus[1][i] && boardStatus[0][i] == boardStatus[2][i]){
                if (boardStatus[0][i]==1){
                    result("X wins!");
                    break;
                }
                else if (boardStatus[0][i]==0) {
                    result("O wins!");
                    break;
                }
            }
        }

        if(boardStatus[0][0] == boardStatus[1][1] && boardStatus[0][0] == boardStatus[2][2]){
            if (boardStatus[0][0]==1){
                result("X wins!");
            }
            else if (boardStatus[0][0]==0) {
                result("O wins!");
            }
        }

        if(boardStatus[0][2] == boardStatus[1][1] && boardStatus[0][2] == boardStatus[2][0]){
            if (boardStatus[0][2]==1){
                result("X wins!");
            }
            else if (boardStatus[0][2]==0) {
                result("O wins!");
            }
        }
    }

    private void enableAllBoxes(boolean value){
        Log.d(TAG, "Inside enableAllBoxes");
        button00.setEnabled(value);
        button01.setEnabled(value);
        button02.setEnabled(value);

        button10.setEnabled(value);
        button11.setEnabled(value);
        button12.setEnabled(value);

        button20.setEnabled(value);
        button21.setEnabled(value);
        button22.setEnabled(value);
    }

    private void result(String winner){
        Log.d(TAG, "Inside result");

        setInfo(winner);
        enableAllBoxes(false);
    }

    private void resetBoard(){
        Log.d(TAG, "Inside resetBoard");
        button00.setText("");
        button01.setText("");
        button02.setText("");

        button10.setText("");
        button11.setText("");
        button12.setText("");

        button20.setText("");
        button21.setText("");
        button22.setText("");

        enableAllBoxes(true);

        PLAYER_X = true;
        TURN_COUNT = 0;

        initializeBoardStatus();

        setInfo("Player X's Turn");
    }

    private void setInfo(String text){
        displayText.setText(text);
    }

    private void initializeBoardStatus(){
        for(int i = 0; i < 3; i++){
            for(int j = 0; j < 3; j++){
                boardStatus[i][j] = -1;
            }
        }
    }
}