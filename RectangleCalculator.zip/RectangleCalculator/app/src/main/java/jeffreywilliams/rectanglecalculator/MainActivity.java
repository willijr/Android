package jeffreywilliams.rectanglecalculator;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

import java.text.NumberFormat;


public class MainActivity extends Activity
        implements OnEditorActionListener{

    // define variables for the widgets
    private EditText widthEditText;
    private EditText lengthEditText;
    private TextView areaTextView;
    private TextView perimeterTextView;

    // define the SharedPreferences object
    private SharedPreferences savedValues;

    // define instance variables that should be saved
    private String widthString = "";
    private String lengthString = "";

    // define instance variables that should be saved
    private double width = 0.00;
    private double length = 0.00;
    private double area = 0.00;
    private double perimeter = 0.00;

    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get references to the widgets
        widthEditText = findViewById(R.id.widthEditText);
        lengthEditText = findViewById(R.id.lengthEditText);
        areaTextView = findViewById(R.id.areaTextView);
        perimeterTextView = findViewById(R.id.perimeterTextView);

        // set the listeners
        widthEditText.setOnEditorActionListener(this);
        lengthEditText.setOnEditorActionListener(this);

        // get SharedPreferences object
        savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);
    }

    @Override
    public void onPause() {
        // save the instance variables
        SharedPreferences.Editor editor = savedValues.edit();
        editor.putString("widthString", widthString);
        editor.putString("lengthString", lengthString);
        editor.apply();

        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();

        // get the instance variables
        widthString = savedValues.getString("widthString", "");
        lengthString = savedValues.getString("lengthString", "");

        // set the bill amount on its widget
        widthEditText.setText(widthString);
        lengthEditText.setText(lengthString);

        // calculate and display
        //calculateAndDisplay();
    }

    public void calculateAndDisplay(){

        // get the width and length amount
        widthString = widthEditText.getText().toString();
        lengthString = lengthEditText.getText().toString();
        if (widthString.equals("")) {
            width = 0.00;
        }
        else {
            width = Double.parseDouble(widthString);
        }
        if (lengthString.equals("")) {
            length = 0.00;
        }
        else {
            length = Double.parseDouble(lengthString);
        }

        // calculate area and perimeter
        area = width * length;
        perimeter = 2 * width + 2 * length;

        // display the results with formatting
        //NumberFormat number = NumberFormat.getNumberInstance();
        areaTextView.setText(String.format("%.2f", area));
        perimeterTextView.setText(String.format("%.2f", perimeter));
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_UNSPECIFIED) {
            calculateAndDisplay();
        }
        return false;
    }
}
