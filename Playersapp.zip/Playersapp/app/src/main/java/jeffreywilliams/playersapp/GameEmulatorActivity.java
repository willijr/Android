package jeffreywilliams.playersapp;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import static jeffreywilliams.playersapp.TaskListDB.TASK_ID;
import static jeffreywilliams.playersapp.TaskListDB.TASK_ID_COL;
import static jeffreywilliams.playersapp.TaskListDB.TASK_LIST_ID_COL;
import static jeffreywilliams.playersapp.TaskListDB.TASK_LOSSES_COL;
import static jeffreywilliams.playersapp.TaskListDB.TASK_NAME;
import static jeffreywilliams.playersapp.TaskListDB.TASK_NAME_COL;
import static jeffreywilliams.playersapp.TaskListDB.TASK_TABLE;
import static jeffreywilliams.playersapp.TaskListDB.TASK_TIES_COL;
import static jeffreywilliams.playersapp.TaskListDB.TASK_WINS;
import static jeffreywilliams.playersapp.TaskListDB.TASK_WINS_COL;

public class GameEmulatorActivity extends MainMenuActivity {

    StringBuilder sb = new StringBuilder();
    TaskListDB db = new TaskListDB( this );


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_emulator);

        final TextView textView3 = findViewById(R.id.textView3);
        final TextView textView4 = findViewById(R.id.textView4);
        Button btn6 = findViewById(R.id.button6);
        Button btn7 = findViewById(R.id.button7);
        Button btn8 = findViewById(R.id.button8);

        textView3.setText(player1Name);
        textView4.setText(player2Name);
        btn6.setText(player1Name + "  WINS! ");
        btn7.setText(player2Name + "  WINS! ");

        final ContentValues cv = new ContentValues();


        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Task player1task;
                db.getTask( player1Id );
                int num1 = (int) player1Id;
                player1task = new Task(num1, 1, player1Name, +1, +0, +0);
                long updateId = db.updateTask( player1task );
                if (updateId > 0) { sb.append(player1Name + "WINS!!!"); }

                Task player2task;
                db.getTask( player2Id );
                int num2 = (int) player2Id;
                player2task = new Task(num2, 1, player1Name, +0, +1, +0);
                updateId = db.updateTask( player2task );
                if (updateId > 0) { sb.append(player1Name + "WINS!!!"); }
            }
        });

        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Task player1task;
                db.getTask( player1Id );
                int num1 = (int) player1Id;
                player1task = new Task(num1, 1, player1Name, +0, +1, +0);
                long updateId = db.updateTask( player1task );
                if (updateId > 0) { sb.append(player2Name + "WINS!!!"); }

                Task player2task;
                db.getTask( player2Id );
                int num2 = (int) player2Id;
                player2task = new Task(num2, 1, player1Name, +1, +0, +0);
                updateId = db.updateTask( player2task );
                if (updateId > 0) { sb.append(player2Name + "WINS!!!"); }
            }
        });
        btn8.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Task player1task;
                db.getTask( player1Id );
                int num1 = (int) player1Id;
                player1task = new Task(num1, 1, player1Name, +0, +0, +1);
                long updateId = db.updateTask( player1task );
                if (updateId > 0) { sb.append(" IT IS A TIE!!!"); }

                Task player2task;
                db.getTask( player2Id );
                int num2 = (int) player2Id;
                player2task = new Task(num2, 1, player1Name, +0, +0, +1);
                updateId = db.updateTask( player2task );
                if (updateId > 0) { sb.append(" IT IS A TIE!!!"); }
            }
        });


    }


}
