package jeffreywilliams.playersapp;

public class Task {

    private long taskId;
    private long listId;
    private String name;
    private int wins;
    private int losses;
    private int ties;
    
    public Task() {
        name = "";
    }

    public Task(int listId, String name, int wins, int losses, int ties) {
        this.listId = listId;
        this.name = name;
        this.wins = wins;
        this.losses = losses;
        this.ties = ties;
    }

    public Task(int taskId, int listId, String name, int wins,
            int losses, int ties) {
        this.taskId = taskId;
        this.listId = listId;
        this.name = name;
        this.wins = wins;
        this.losses = losses;
        this.ties = ties;
    }

    public long getId() {
        return taskId;
    }

    public void setId(long taskId) {
        this.taskId = taskId;
    }
    
    public long getListId() {
        return listId;
    }

    public void setListId(long listId) {
        this.listId = listId;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public int getWins() {
        return wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }
    
    public int getLosses() {
        return losses;
    }

    public void setLosses(int losses) { this.losses = losses; }
    
    public int getTies(){
        return ties;
    }
    
    public void setTies(int ties) {
        this.ties = ties;
    }

    public String toString() { return name; }

}