package jeffreywilliams.playersapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import static jeffreywilliams.playersapp.TaskListDB.TASK_LOSSES;
import static jeffreywilliams.playersapp.TaskListDB.TASK_NAME;
import static jeffreywilliams.playersapp.TaskListDB.TASK_TABLE;
import static jeffreywilliams.playersapp.TaskListDB.TASK_TIES;
import static jeffreywilliams.playersapp.TaskListDB.TASK_WINS;

public class ScoreBoardActivity extends MainMenuActivity {

    TaskListDB db = new TaskListDB( this );
    StringBuilder sb = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_scoreboard );


        ArrayList<Task> tasks = db.getTasks();
        for (Task t : tasks) {
            sb.append(t.getName()).append("           ").append(t.getWins()).append(t.getLosses())
                    .append(t.getTies()).append("\n");
        }
        final ListView lv = findViewById (R.id.listView3);
        ArrayAdapter<Task> arrayAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tasks);
        lv.setAdapter(arrayAdapter);
    }
}