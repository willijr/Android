package jeffreywilliams.playersapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;

public class MainMenuActivity extends AppCompatActivity {

    public static String player1Name = " ";
    public static String player2Name = " ";
    long player1Id;
    long player2Id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        Button btn1 = findViewById(R.id.button1);
        Button btn2 = findViewById(R.id.button2);
        Button btn3 = findViewById(R.id.button3);
        Button btn4 = findViewById(R.id.button4);
        Button btn5 = findViewById(R.id.button5);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!player1Name.equals(" ") && !player2Name.equals(" "))
                    startActivity(new Intent(MainMenuActivity.this, GameEmulatorActivity.class));
                else if (player1Name.equals(" "))
                    startActivity(new Intent(MainMenuActivity.this, SelectPlayer1Activity.class));
                else if (player2Name.equals(" "))
                    startActivity(new Intent(MainMenuActivity.this, SelectPlayer2Activity.class));            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!player1Name.equals(" ") && !player2Name.equals(" "))
                startActivity(new Intent(MainMenuActivity.this, ScoreBoardActivity.class));
                else if (player1Name.equals(" "))
                    startActivity(new Intent(MainMenuActivity.this, SelectPlayer1Activity.class));
                else if (player2Name.equals(" "))
                    startActivity(new Intent(MainMenuActivity.this, SelectPlayer2Activity.class));
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainMenuActivity.this, SelectPlayer1Activity.class));
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainMenuActivity.this, SelectPlayer2Activity.class));
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainMenuActivity.this, AddPlayerActivity.class));
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()) {
            case R.id.menu_game:
                Toast.makeText(this, "Game", Toast.LENGTH_SHORT).show();
                if (!player1Name.equals(" ") && !player2Name.equals(" "))
                startActivity(new Intent(MainMenuActivity.this, GameEmulatorActivity.class));
                else if (player1Name.equals(" "))
                    startActivity(new Intent(MainMenuActivity.this, SelectPlayer1Activity.class));
                else if (player2Name.equals(" "))
                    startActivity(new Intent(MainMenuActivity.this, SelectPlayer2Activity.class));
                return true;
            case R.id.menu_score:
                Toast.makeText(this, "Score Board", Toast.LENGTH_SHORT).show();
                if (!player1Name.equals(" ") && !player2Name.equals(" "))
                    startActivity(new Intent(MainMenuActivity.this, ScoreBoardActivity.class));
                else if (player1Name.equals(" "))
                    startActivity(new Intent(MainMenuActivity.this, SelectPlayer1Activity.class));
                else if (player2Name.equals(" "))
                    startActivity(new Intent(MainMenuActivity.this, SelectPlayer2Activity.class));                return true;
            case R.id.menu_player1:
                Toast.makeText(this, "Player1", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainMenuActivity.this, SelectPlayer1Activity.class));
                return true;
            case R.id.menu_player2:
                Toast.makeText(this, "Player2", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainMenuActivity.this, SelectPlayer2Activity.class));
                return true;
            case R.id.menu_add:
                Toast.makeText(this, "Add a Player", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainMenuActivity.this, AddPlayerActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
