package jeffreywilliams.playersapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class SelectPlayer1Activity extends MainMenuActivity {

    TaskListDB db = new TaskListDB( this );
    StringBuilder sb = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_select_player_1 );

        ArrayList<Task> tasks = db.getTasks();
        for (Task t : tasks) {
            //           sb.append( "   " ).append( t.getName() ).append( "\n" );
            sb.append(t.getName());
        }
        final ListView lv = findViewById (R.id.listView1);
        ArrayAdapter<Task> arrayAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tasks);
        lv.setAdapter(arrayAdapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                player1Name = lv.getItemAtPosition(position).toString();
                player1Id = id;
                if (player2Name.equals(" "))
                    startActivity(new Intent(SelectPlayer1Activity.this, SelectPlayer2Activity.class));
                else
                    startActivity(new Intent(SelectPlayer1Activity.this, GameEmulatorActivity.class));
            }
        });
    }
}