package jeffreywilliams.playersapp;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

public class AddPlayerActivity extends MainMenuActivity implements TextView.OnEditorActionListener {

    private EditText editText;
    TaskListDB db = new TaskListDB(this);
    StringBuilder sb = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_add_player );

        editText = findViewById( R.id.editTextView1 );
        editText.setOnEditorActionListener( this );
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        String player;
        player = editText.getText().toString();
        if (actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_UNSPECIFIED) {
            Task task = new Task( 1,1, player, 0, 0, 0 );
            long insertId = db.insertTask( task );
            if (insertId > 0) {
                sb.append("Row inserted! Insert Id: ").append(insertId).append("\n");
            }
            editText.getText().clear();
        }
        return false;
    }
}
