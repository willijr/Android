package jeffreywilliams.measurementconverter;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements TextView.OnEditorActionListener {

    private EditText label1EditText;
    private TextView label2TextView;
    private TextView label1Label;
    private TextView label2Label;
    private SharedPreferences savedValues;
    private String measurement = "";
    private double measure = 0.00;
    private double newMeasure = 0.00;
    private double ratio = 0;
    String miles = "Miles";
    String kilometers = "Kilometers";
    String inches = "Inches";
    String centimeters = "Centimeters";

    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        label1EditText = (EditText) findViewById(R.id.label1EditText);
        label2TextView = findViewById(R.id.label2TextView);
        label1Label = findViewById(R.id.label1Label);
        label2Label = findViewById(R.id.label2Label);

        savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);

        label1EditText.setOnEditorActionListener(this);

        Spinner spinner_convert_from = (Spinner) findViewById(R.id.conversionSpinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
               R.array.conversion_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_convert_from.setAdapter(adapter);
        spinner_convert_from.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {

                measurement = label1EditText.getText().toString();

                if (pos == 0) {
                    label1Label.setText(miles);
                    label2Label.setText(kilometers);
                    ratio = 1.6093;
                    calculateAndDisplay();
                }
                else if (pos == 1) {
                    label1Label.setText(kilometers);
                    label2Label.setText(miles);
                    ratio = 0.6214;
                    calculateAndDisplay();
                }
                else if (pos == 2) {
                    label1Label.setText(inches);
                    label2Label.setText(centimeters);
                    ratio = 2.54;
                    calculateAndDisplay();
                }
                else if (pos == 3) {
                    label1Label.setText(centimeters);
                    label2Label.setText(inches);
                    ratio = 0.3937;
                    calculateAndDisplay();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    @Override
    public void onPause() {
        SharedPreferences.Editor editor = savedValues.edit();
        editor.putString("measurement", measurement);
        editor.apply();

        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        measurement = savedValues.getString("measurement", "");
    }

    public void calculateAndDisplay(){
        if (measurement.equals("")) {
            measure = 0.00;
        }
        else {
            measure = Double.parseDouble(measurement);
        }
        newMeasure = measure * ratio;
        newMeasure = Double.parseDouble(new DecimalFormat("##.##").format(newMeasure));
        label2TextView.setText(String.valueOf(Double.valueOf(newMeasure)));
    }

    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_UNSPECIFIED) {
            measurement = label1EditText.getText().toString();
            if (label1Label.getText() == "Miles")
                ratio = 1.6093;
            else if (label1Label.getText() == "Kilometers")
                ratio = 0.6214;
            else if (label1Label.getText() == "Inches")
                ratio = 2.54;
            else if (label1Label.getText() == "Centimeters")
                ratio = 0.3937;
            else
                ratio = 0.00;
            calculateAndDisplay();
        }
        return false;
    }
}